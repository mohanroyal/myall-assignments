SELECT * FROM Employees
WHERE TitleOfCourtesy IN('Mr.','Dr.');