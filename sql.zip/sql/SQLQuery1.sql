/*creating new database*/
create database Desdata1

/*Drop database royal*/
Drop database Mohan
/* location of mdf file */

SELECT SUBSTRING(physical_name, 1,
CHARINDEX(N'master.mdf',
LOWER(physical_name)) - 1) Database_File_Location
FROM master.sys.master_files
WHERE database_id = 1 AND FILE_ID = 1