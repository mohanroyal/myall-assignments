SELECT *
 FROM products
 WHERE productID IN(1,2)
