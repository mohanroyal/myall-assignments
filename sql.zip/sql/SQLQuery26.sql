Use Northwind
If Exists (Select * from sysobjects where name = 'banktrans')
Begin
DROP Procedure banktrans
End
GO
Create Procedure sp_banktrans
as
Begin
Begin Transaction
Declare @accno int,@trans_type CHAR,@amt
int,@tot_bal int,@total int
Declare CASH_cur cursor for select acc_no,tot_bal,trans_type,amt
from bank_trans3
Set @tot_bal =0
OPEN CASH_cur
FETCH NEXT FROM CASH_cur INTO @accno,@total,@trans_type,@amt
While @@fetch_status = 0
Begin
If @trans_type = 'd'
Begin
SET @tot_bal = @total + @amt
End
Else
Set @tot_bal = @total - @amt
Update bank_trans3 SET tot_bal = @tot_bal
WHERE acc_no = @accno
Set @tot_bal =0
FETCH NEXT FROM
CASH_cur INTO @accno,@total,@trans_type,@amt
Continue
End
CLOSE CASH_cur
Commit Transaction