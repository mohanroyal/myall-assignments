create table category (catid int  not null identity primary key,name varchar(50) not null )
create table product (productid int not null identity primary key,catid int null references category(catid),productname varchar(50) not null)
insert into category
values('animal'),('fruits'),('humans')
insert into product (catid,productname)
values(1,'babul'), (2,'jsh')

delete from product
where productname= 'babul'

drop table product
insert into product (catid,productname)
values(1,'babul'), (2,'jsh')


create table product (productid int not null identity primary key,catid int null references category(catid),productname varchar(50) not null)



create table products (productid int not null identity primary key,catid int null references category(catid),productname varchar(50) not null)

insert into products(catid,productname)
values(1,'babul'), (2,'jsh')




create table prodtable (prodid int not null identity primary key,catid int null references category(catid),prodname varchar(50) not null)



insert into category
values('cgdggg'), ('vnhghghgh')




insert into products(catid,productname)
values(1,'babul'), (2,'jsh')




drop table prodtable


drop table product





create table prodtable (prodid int not null identity primary key,catid int not null ,prodname varchar(50) not null)

set identity_insert prodtable on

insert into prodtable(prodid,catid,prodname)
values(44,1,'babul'), (66,2,'jsh')
