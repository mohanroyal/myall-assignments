create procedure
sp_employees_us
as 
select * from Employees
where Country='usa'and TitleOfCourtesy='ms.'
execute sp_employees_us


drop sp_employees_us




create trigger convertandinsert

on employees
after insert,update
as
     BEGIN
	   update Employees
	   set FirstName=UPPER (firstname)
	   where EmployeeID in(select EmployeeID from insert)
