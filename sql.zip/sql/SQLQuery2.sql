
 use Desdata1
 go
  
  
 Create table student
 (
         Id   int  identity  primary key  NOT null ,
		 departmen  varchar(50) not null, name varchar(50) 
		 )

		 use Desdata1
 go
  

		 create table cates(catid int not null identity primary key,catname varchar not null)
		 create table produc(proid int not null,catid int not null references cates(catid))
		 insert into cates
		 values('animals'),('fruits'),('companies')