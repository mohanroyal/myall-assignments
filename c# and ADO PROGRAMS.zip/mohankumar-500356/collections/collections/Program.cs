﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace collections
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arr = new ArrayList();
            arr.Add(getid());
            arr.Add(getname());
            arr.Remove(id);
           
           

        }
       private static  object getid()
        {
            int id;
            Console.WriteLine("enter id");
            int.Parse(Console.WriteLine(), out id);
        }
        private static object getname()
        {
            string name;
        } 
    }
} 
