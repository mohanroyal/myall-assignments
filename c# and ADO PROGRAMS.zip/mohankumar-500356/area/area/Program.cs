﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace area
{
    class program
    {
        static void Main(string[] args)
        {

        }
        class Shape
        {
            static void intialisation(double length, double breadth)
            {
                Console.WriteLine("area of rectangle");
                
            }



        }

        class Triangle : Shape
        {

        }

        class Rectangle : Shape
        {

        }
    }  }