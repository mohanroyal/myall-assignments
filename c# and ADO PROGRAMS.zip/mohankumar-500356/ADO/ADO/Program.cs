﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO
{
    class Program
    {
        static string conString = @"Server=INCHCMPC011397;Database=Northwind;Trusted_Connection=True;";
        static void Main(string[] args)
        {
            try
            {
                DisplayData();

                //InsertData();

               // Dis

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DisplayData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandText = @"select * from employees";
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Console.WriteLine($"FirstName = {rdr["FirstName"]} LastName = {rdr["LastName"]}");

                    }
                }
            }
        }
    }
}
