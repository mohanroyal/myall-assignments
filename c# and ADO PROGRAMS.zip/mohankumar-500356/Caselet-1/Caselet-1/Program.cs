﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caselet_1
{
    class Bank
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to XYZ Bank");
            Account a = new SavingsAccount();           
            Account.Generateaccountnumber();


           
        }
    }
}
