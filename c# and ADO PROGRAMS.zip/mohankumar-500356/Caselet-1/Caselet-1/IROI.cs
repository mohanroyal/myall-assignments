﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Caselet_1
//{
//    interface IROI
//    {
//        private int a;

//        int A { get; set; }
//    }
//}
