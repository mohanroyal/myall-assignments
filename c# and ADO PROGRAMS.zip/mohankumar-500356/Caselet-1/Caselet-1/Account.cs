﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caselet_1
{
   public class Account
    {

        string username;
        int balance;
        string name;
        private  readonly object AccountNumber;
        string acno;
       public Account()
        {
            AccountNumber = acno;
        }
        
            
        public void OpenAccount()
        {
            List<SavingsAccount> SavingsList = new List<SavingsAccount>();
            var u1 = Console.ReadLine();
            SavingsList.Add(new SavingsAccount());
            Console.WriteLine("Enter the Username " );
            username = Console.ReadLine();
            Console.WriteLine();
            Generateaccountnumber();            
        }

        public static void Generateaccountnumber()
        {
            Account a = new Account();
            Random r = new Random();
            string w = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                var acno = w;
            }

            Console.WriteLine(a.AccountNumber);

             Console.ReadLine();
        }       
        //public abstract void CLoseAccount();
        //public abstract void EditAccount();
        //public abstract void Deposit();
        //public abstract void Withdrawal();
        //public abstract void CheckBalance();


//        OpenAccount()
//CloseAccount()
//EditAccount()
//Deposit()
//Withdrawal()
//Check_Balance()



    }
}
