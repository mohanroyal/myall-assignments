﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverse_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            int rev = 0;
            Console.WriteLine("enter number");
       num  =   int.Parse(Console.ReadLine());
            while (num !=0)
            {
                int r = num % 10;
                rev = rev * 10 + r;
                num = num / 10;

            }
            Console.WriteLine("reverse num is" + rev);
        }
    }
}