﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bank
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" enter name");
            string name = Console.ReadLine();
            Console.WriteLine("accont number");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("enter type of accont");
            string type = Console.ReadLine();
            Console.WriteLine("Enter  Balance amount ");
            double Balamount = Convert.ToInt32(Console.ReadLine());
            Details d = new bank.Details();
            Details.Deposit(Balamount);
            Details.Withdraw();
            Details.Balance();
       }
    }
    class Details
    {
        static double Totalamnt;
        static double wamount;
        static double depamnt;
        static void Disp()
        {
            Console.WriteLine("details are:");
        }
       public static void Deposit( double Balamount)
        {
            
            Console.WriteLine("enter amount to deposit");
            depamnt=Convert.ToInt32(  Console.ReadLine());
            Totalamnt = Balamount+depamnt;
            Console.WriteLine("Deposied Amount is\t"+depamnt);
        }
        public static void Withdraw()
        {
            Console.WriteLine("enter amount to withdraw");
            wamount = Convert.ToInt32(Console.ReadLine());
            if (wamount < Totalamnt)
            {
                Console.WriteLine("transaction succesfull Amount withdrawn\t"+wamount);
            }
            else
            {
                Console.WriteLine("Insufficient Balance");
                wamount = 0;
            } 

        }
        public static void Balance()
        {
            double balance = Totalamnt - wamount;
            Console.WriteLine("your balance amnt is:"+balance);
        }

    }

}