﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fibnocci
{
    class Program
    {
        static void fib(int n)
        {
           if(n==0||n==1)
            {
                Console.WriteLine(0);
                return;
            }
            int k = 0;
            int f1 = 0, f2 = 1,f3;
               
          while(k<n)
            {
                Console.WriteLine(f1);
                f3 = f1 + f2;
                f1 =f2;
                f2 = f3;
                k++;
            }

        }
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("enter num");
            n=int.Parse(Console.ReadLine());
            fib(n);
           
        }
    }
}
