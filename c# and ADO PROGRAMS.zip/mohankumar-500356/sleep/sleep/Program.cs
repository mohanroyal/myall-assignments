﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sleep
{
    class Program
    {
        ~Program() { }

        static void Main(string[] args)
        {
        }
     public static void count()
        {
            for (int i=0;i<50;i++)
            { 
                Console.WriteLine(i);
            if(i)
        }
    }
}
