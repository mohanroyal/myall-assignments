﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseNum
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, temp;
            int rev = 0;
            Console.WriteLine("Enter the choice of your number");
            int.TryParse(Console.ReadLine(), out num);
            temp = num;
            while (temp > 0)
            {
                int rem = temp % 10;
                rev = (rev * 10) + rem;
                temp = temp / 10;


            }
           
                Console.WriteLine("The reverse is" + rev);
                Console.ReadLine();

            
        }
    }
}
