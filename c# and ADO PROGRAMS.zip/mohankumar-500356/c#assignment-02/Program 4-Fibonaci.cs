﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fibonaci
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 1;
            int num2 = 1;
            int num3 = 0;
            int num;
            Console.WriteLine("Enter the range for which you want fibonaci series");
            int.TryParse(Console.ReadLine(), out num);

            Console.Write($"{num1} {num2}   ");
            for(int i=3;i<=num;i++)
            {
                num3 = num1 + num2;
                Console.Write($"{num3} ");
                num1 = num2;
                num2 = num3;
            }
            Console.ReadLine();
        }
    }
}
