﻿//Interface Program
using System;

interface IPerson
{
    void Introduce();

}

interface IPrivilege
{
    void JoinClub();
}

class SalEmp : IPerson, IPrivilege
{
    int id;
    String firstname;
    String lastname;

    public void Introduce()
    {
        Console.WriteLine("enter ur id");
        id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter ur firstname");
        firstname = Console.ReadLine();
        Console.WriteLine("enter ur lastname");
        lastname = Console.ReadLine();
    }

    public void JoinClub()
    {
        Console.WriteLine("Hi,i am {0} {1},i am member of the club", firstname, lastname);
    }

}

class ConEmp : IPerson
{
    int id;
    String firstname;
    String lastname;

    public void Introduce()
    {
        Console.WriteLine("enter ur id");
        id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter ur firstname");
        firstname = Console.ReadLine();
        Console.WriteLine("enter ur lastname");
        lastname = Console.ReadLine();
        Console.WriteLine("Hi,i am {0} {1}", firstname, lastname);
    }

}

class Mainclass
{
    public static void Main()
    {
        SalEmp se = new SalEmp();
        ConEmp ce = new ConEmp();
        Console.WriteLine("Welcome to EMS");
        Console.WriteLine("1. Salaried Employee");
        Console.WriteLine("2. Contract Employee");
        int choice = Convert.ToInt32(Console.ReadLine());

        switch (choice)
        {
            case 1:
                se.Introduce();
                se.JoinClub();
                break;

            case 2:
                ce.Introduce();
                break;
        }
        Console.ReadLine();

    }

 ?}