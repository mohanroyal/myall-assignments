﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IsPrime
{
    class Program
    {
        public int count1 = 0;
        public int num;

        public void IsPrime()
        {
            for (int i = 2; i < num; i++)
            {
                if (num % i == 0)
                {
                    count1++;
                    //Console.WriteLine("false");
                }
            }
                if(count1>=1)
                {
                    Console.WriteLine("false");
                }
                else
                {
                    Console.WriteLine("true");
                }
            
        }
        class Check
        {
            static void Main(string[] args)
            {
                Program p1 = new Program();
                Console.WriteLine("Enter the number to check");
                int.TryParse(Console.ReadLine(), out p1.num);
                p1.IsPrime();
                Console.ReadLine();

            }
        }
    } }
