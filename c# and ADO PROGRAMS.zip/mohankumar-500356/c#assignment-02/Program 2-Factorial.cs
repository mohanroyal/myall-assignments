﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            int fact = 1;
            Console.WriteLine("Enter number you want to find factorial");
            int.TryParse(Console.ReadLine(), out num);
            for(int i=num;i>0;i--)
            {
                fact = fact * num;

            }
            Console.WriteLine("Factorial of" + num + "is" + fact);
            Console.ReadLine();
        }
    }
}
