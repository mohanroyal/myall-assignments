﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the date");
            int d = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the month");
            int m = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the year");
            int y = int.Parse(Console.ReadLine());
            DateTime dt = DateTime.Now;
            DateTime A = new DateTime(d, m, y);
            Console.WriteLine("The difference interms of days is" + A.Subtract(dt).Days);
            Console.WriteLine("The difference interms of minutes is" + A.Subtract(dt).Minutes);
            Console.WriteLine("The difference interms of seconds is" + A.Subtract(dt).Seconds);
            Console.WriteLine(A.ToLongDateString());
            Console.ReadLine();

        }
    }
}
