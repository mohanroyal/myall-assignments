﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication38
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1.palindrome 2.anagram");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    {
                        string s;
                        string revs = "";
                        Console.WriteLine("enter a sentence or word to check palindrome or not");
                        s = Console.ReadLine();

                        for (int i = s.Length - 1; i >= 0; i--)
                        {
                            revs += s[i];
                        }
                        if (revs == s)
                        {
                            Console.WriteLine($"{s} is palindrome");
                        }
                        else
                        {
                            Console.WriteLine($"{s} is not palindrome");
                        }



                    }
                    break;
                case 2:
                    {
                        Console.WriteLine("enter first string");
                        string str1 = Console.ReadLine();
                        Console.WriteLine("enter second string");
                        string str2 = Console.ReadLine();

                        bool isAnagram = (((str1 + str2).Any(c => str1.Count(x => x == c) != str2.Count(x => x == c))));
                        if (isAnagram)
                        {
                            Console.WriteLine($"string {str1} and string {str2} are not anagram");
                        }
                        else
                        {
                            Console.WriteLine($"string { str1}  and string { str2} are Anagram");
                        }
                    }
                    break;
            }


            Console.ReadLine();


        }

    }
}
