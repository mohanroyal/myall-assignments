﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mean_Median
{
    class Program
    {
        static void Main(string[] args)
        {
            double mean = 0;
            int mid = 0;
            int temp=0;
            Console.WriteLine("Enter the range");
            int n;
            int.TryParse(Console.ReadLine(), out n);
            int[] arr = new int[n];

            for (int i = 0; i < n;i++)
            {
                Console.WriteLine($"enter{i+1} number");
                int.TryParse(Console.ReadLine(), out arr[i]);
            }

            for (int i = 0; i < n; i++)
            {
                mean = (mean + arr[i]) ;
            }
            Console.WriteLine($"Mean is{mean/n}");

               

            if(n%2!=0)
            {
                
                     mid = n / 2;

                    
                
                 temp = arr[mid];
                Console.WriteLine($"Median is {temp}");
            }
                 else if(n%2==0)
            {
                mid = n / 2;
                    int temp1 = ((mid + 1) + (mid - 1)) / 2;
                
                int temp2 = arr[mid];
                Console.WriteLine($"Median is {temp2}");

            }
            
           
            Console.ReadLine();
        }
    }
}
