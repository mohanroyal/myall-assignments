﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interest
{
    class Program
    {
        static void Main(string[] args)
        {
            int Amt, Prncpl, Time;
            int Rate = 2;
            Console.WriteLine("Enter your principal amount");
            int.TryParse(Console.ReadLine(), out Prncpl);

            Console.WriteLine("Enter your Time duration");
            int.TryParse(Console.ReadLine(), out Time);
            int SI=(Prncpl*Rate*Time)/100;

            Console.WriteLine($"Interset for { Time} period for Principal amount of{ Prncpl} is {SI}");
            Console.ReadLine();
        }
    }
}
