﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace US_INR
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your INR amount");
            double num;
            double.TryParse(Console.ReadLine(), out num);

            double Dollar = 65.48 * num; ;
            double Pound = 81.19 * num; ;

            Console.WriteLine($"Dollar conversion of{num} is{Dollar}");
            Console.WriteLine($"Pound conversion of {num} is {Pound}");

            Console.ReadLine();

        }
    }
}
