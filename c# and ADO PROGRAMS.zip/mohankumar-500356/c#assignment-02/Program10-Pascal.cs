﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacalTriangle
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch;
            int val = 1;
            Console.WriteLine("Enter your choice for number of rows you want Pacal's traingle");
            int.TryParse(Console.ReadLine(), out ch);

            for(int i=0;i<=ch;i++)
            {
                for(int j=1;j<=i;j++)
                {
                    if(j==i||j==1)
                    {
                        val = 1;
                        Console.Write($" {val}");
                    }
                    else 
                    {
                        val = val * (i - j + 1) / j;
                        Console.Write($" {val}");
                    }
                    
                   
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
