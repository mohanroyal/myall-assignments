﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace moneyconverter
{
    class Program
    {
        static double rupee(double n)
        {
            return n * 68.73;
        }
        static double pound(double n)
        {
            return n * 0.81;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("enter the amount in dollar $$");
            double n = double.Parse(Console.ReadLine());
            Console.WriteLine("1. Press 1 to convert dollars to indian rupees\n 2. Press 2 to convert dollar to british pound");
            int choice = int.Parse(Console.ReadLine());
            switch(choice)
            {
                case 1: Console.WriteLine(n+"$ is "+rupee(n)+"Rs");
                    break;
                case 2: Console.WriteLine(n+"$ is "+pound(n)+"Pounds");
                    break;
                default : Console.WriteLine("Invalid Choice");
                    break;
            }    
        }
    }
}
