﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    interface ITranscation
    {

               void transferAmount();
    }
    interface IROI
    {
        double getRateOfInterest();
    }

    class SavingAccount : Account, IROI, ITranscation
    {
        const int maxAmountPerDay = 25000;
        const int minBalanceRequired = 1000;
        public override void deposit()
        {
            Console.WriteLine("enter the amount to deposite");
            int damt = int.Parse(Console.ReadLine());
            if (damt < maxAmountPerDay)
            {
                int balance = getBalance() + damt;
                setBalance(balance);
            }
            else
                throw new MaxAmountPerDayException();
        }

        public override void getAccountDetail()
        {
            Console.WriteLine("AccountNo:" + getAccountNo() + "\nAvailable Balance:" + getBalance() + "UserName:" + getUserName());
        }

        public void transferAmount()
        {
            Console.WriteLine("enter the amount u want to transfer ");
            int tamt = int.Parse(Console.ReadLine());
            if (tamt < maxAmountPerDay)
            {
                if (getBalance() < tamt)
                {
                    int nwbal = getBalance() - tamt;
                    if (nwbal > minBalanceRequired)
                    {
                        setBalance(nwbal);
                    }
                    else throw new MinBalanceException();
                }
            }
            else
                throw new MaxAmountPerDayException();
        }

        double IROI.getRateOfInterest()
        {
            return 12;
        }
        public override int withdraw()
        {
            Console.WriteLine("enter the amount u want to withdraw:");
            int amt = int.Parse(Console.ReadLine());
            if (amt < maxAmountPerDay)
            {
                if (getBalance() < amt)
                {
                    int nwbal = getBalance() - amt;
                    if (nwbal > 1000)
                    {
                        setBalance(nwbal);
                    }
                    else throw new MinBalanceException();
                }
            }
            else
                throw new MaxAmountPerDayException();
            return amt;
        }
    }
    class CurrentAccount : Account, IROI, ITranscation
    {
        const int minBalanceRequired = 1000;
        const int maxAmountPerDay = 25000;
        public override void deposit()
        {
            Console.WriteLine("enter the amount to deposite");
            int damt = int.Parse(Console.ReadLine());
            if (damt < maxAmountPerDay)
            {
                int balance = getBalance() + damt;
                setBalance(balance);
            }
            else
                throw new MaxAmountPerDayException();
        }

        public override void getAccountDetail()
        {
            Console.WriteLine("AccountNo:" + getAccountNo() + "\nAvailable Balance:" + getBalance() + "UserName:" + getUserName());
        }


        public void transferAmount()
        {
            Console.WriteLine("enter the amount u want to transfer ");
            int tamt = int.Parse(Console.ReadLine());
            if (tamt < maxAmountPerDay)
            {
                if (getBalance() < tamt)
                {
                    int nwbal = getBalance() - tamt - 14;
                    if (nwbal > 1000)
                    {
                        setBalance(nwbal);
                    }
                    else throw new MinBalanceException();
                }
            }
            else
                throw new MaxAmountPerDayException();
        }

        double IROI.getRateOfInterest()
        {
            return 12;
        }
        public override int withdraw()
        {
            Console.WriteLine("enter the amount u want to withdraw:");
            int amt = int.Parse(Console.ReadLine());
            if (amt < maxAmountPerDay)
            {
                if (getBalance() < amt)
                {
                    int nwbal = getBalance() - amt;
                    if (nwbal > 1000)
                    {
                        setBalance(nwbal);
                    }
                    else throw new MinBalanceException();
                }
            }
            else
                throw new MaxAmountPerDayException();
            return amt;
        }
    }
    class MinBalanceException : Exception
    {

    }
    class MaxAmountPerDayException : Exception
    {

    }
    abstract class Account
    {
        long accountNo;
        string userName;
        int balance;
       

        public long getAccountNo()
        {
            return accountNo;
        }
        public void setBalance(int balance)
        {
            this.balance = balance;
        }
        public void setUserName(string userName)
        {
            this.userName = userName;
        }
        public int getBalance()
        {
            return balance;
        }
        public string getUserName()
        {
            return userName;
        }
        public void OpenAccount()
        {
            Console.Write("Opening account");
            Console.WriteLine("Enter the UsrName:");
            string name = Console.ReadLine();
            setUserName(name);
            Console.WriteLine("Enter the amount :");
            int bal;
            int.TryParse(Console.ReadLine(), out bal);
            if (bal > 1000)
            {
                setBalance(bal);
            }
            else
                throw new MinBalanceException();
            Random r = new Random();
            string acc = "";
            for (int i = 0; i < 12; i++)
            {
                acc += r.Next(0, 9).ToString();
            }
            accountNo = Convert.ToInt64(acc);
            Console.WriteLine("ur account number is:" + accountNo);

        }

        public void closeAccount()
        {
            if (balance == 0)
            {
                Console.Write("Closing account");
            }
            else
                Console.Write("Cannot close the account");
        }

        public void editAccount()
        {
            Console.WriteLine("enter the correct userName:");
            String un = Console.ReadLine();
            setUserName(un);
        }

        public abstract void deposit();
        public abstract void getAccountDetail();
        public int checkBalance()
        {
            Console.Write("U Balnace in the account is:");
            return balance;
        }
        public abstract int withdraw();


    }

    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Welcome to citi Bank");
            Console.WriteLine("What account u wish to open(current/savings):");
            string acctype = Console.ReadLine();
            Account c = null;
            if (acctype.Equals("current"))
            {

                try
                {
                    c = new CurrentAccount();
                    c.OpenAccount();
                }
                catch (MinBalanceException m)
                {
                    Console.Write("U should have a minimum balance of 1000Rs.");
                }
            }
            else if (acctype.Equals("savings"))
            {
                try
                {
                    c = new SavingAccount();
                    c.OpenAccount();
                }
                catch (MinBalanceException e)
                {
                    Console.Write("U should have a minimum balance of 1000Rs.");
                }
            }
            Console.WriteLine("What Operation would u like to perform\n");
            Console.WriteLine("1.Deposite\t2.WithDraw\n3.Check balance\t4.Edit Account\n5.Transfer Account\t6.Close Account");
            Console.WriteLine("Choose ur option");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    try
                    {
                        c.deposit();
                    }
                    catch (MaxAmountPerDayException m)
                    {
                        Console.Write(m."u cant deposite more then limited amount");
                    }
                    break;
                case 2:
                    try
                    {
                        c.withdraw();
                    }
                    catch (MinBalanceException min)
                    {
                        Console.Write("ur account should have minimum of 1000Rs");
                    }
                    catch (MaxAmountPerDayException max)
                    {
                        Console.Write("u cant withdraw more then limited amount");
                    }
                    break;
                case 3:
                    int amt = c.checkBalance();
                    Console.WriteLine(amt);
                    break;
                case 4:
                    c.editAccount();
                    break;
                case 5:
                    try
                    {
                        SavingAccount s = (SavingAccount)c;
                        s.transferAmount();
                    }
                    catch (MinBalanceException min)
                    {
                        Console.Write("ur account should have minimum of 1000Rs");
                    }
                    catch (MaxAmountPerDayException max)
                    {
                        Console.Write("u cant withdraw more then limited amount");
                    }

                    break;
                case 6:
                    c.closeAccount();
                    break;
                default: break;
            }
        }
    }
}

​
