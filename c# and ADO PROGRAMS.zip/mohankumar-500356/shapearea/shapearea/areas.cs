﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shapearea
{
    class Program
    {
        static void Main(string[] args)
        {
            Triangle tri = new Triangle();
            double h = tri.getBase(10);
            double b1 = tri.getheight(5);
            double a1 = tri.getArea(b1, h);
            Rectangle rect = new Rectangle();
            double l = rect.getLength(10);
            double b = rect.getWidth(5);
            double a2 = rect.getArea(l, b);
            Console.WriteLine("the area of triangle is" + a1);
            Console.WriteLine("the area of rectangle is" + a2);
        }
        public class shape
        {
            public double getWidth(double n)
            {
                double width = n;
                return width;
            }
            public double getBase(double n)
            {
                double b = n;
                return b;
            }
            public double getLength(double n)
            {
                double length = n;
                return length;
            }
            public double getheight(int n)
            {
                double height = n;
                return height;
            }
            public virtual double getArea(double n, double n1)

            {
                double area = n * n1;
                return area;
            }
        }
        public class Triangle : shape
        {
            public override double getArea(double b, double height)

            {
                double area = 0.5 * b * height;
                return area;
            }
        }
        public class Rectangle : shape
        {
            public override double getArea(double length, double width)

            {
                double area = length * width;
                return area;
            }
        }
    }
}

