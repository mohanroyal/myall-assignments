﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fact
{
    class Program
    {
        static int fact(int n)
        {
            int f = 1;
            if (n == 0)
            {
                return f;
            }
            return n * fact(n - 1);
        }
        static void Main(string[] args)
        {
                
                Console.WriteLine("enter the number");
                 int n = int.Parse(Console.ReadLine());
                     Console.WriteLine( fact(n));
        }
    }
}
