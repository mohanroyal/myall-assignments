﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Produclist
{
    interface IVatCalculation
    {
        double CalculateVAT(double price);
    }
    public class Product
    {
        string ProductName;
        static int productId;
        int Idstore;

        public string productName
        {
            get
            {
                return ProductName;
            }
            set
            {
                ProductName = value;
            }
        }
        public int ProductId
        {
            get
            {
                return ProductId;
            }
            set
            {
                ProductId = value;
            }
        }
        public int idStore
        {
            get
            {
                return Idstore;
            }
            set
            {
                Idstore = value;
            }
        }

    }
    public class Model : Product, IVatCalculation
    {
        int itemModelId;
        string modelName;
        double modelPrice;
        double Vat;
        bool inStock;
        public double CalculateVAT(double price)
        { return price; }

        public int ItemModelId
        {
            get
            {
                return itemModelId;
            }
            set
            {
                itemModelId = value;
            }
        }
        public string ModelName
        {
            get
            {
                return modelName;
            }
            set
            {
                modelName = value;
            }
        }
        public double ModelPrice
        {
            get
            {
                return modelPrice;
            }
            set
            {
                modelPrice = value;
            }
        }
        public bool InStock
        {
            get
            {
                return inStock;
            }
            set
            {
                inStock = value;
            }
        }
        public double CaluculateVat(double price)
        {
            return (4.5 * price) % 100;
        }
        public override string ToString()
        {

            return "Product Id: " + ProductId + "\nProduct Name: " + productName + "\nItem Model Id: " + ItemModelId +
                    "\nModel Name: " + ModelName + "\nModel Price: " + ModelPrice + "\tVAT: " + Vat + "\tTotal: " + (ModelPrice + Vat) + "\nIn Stock: " + InStock;

        }
        public Model(int productId, string productName, int modelId, string modelName, double modPrice, double VAT, bool modInStock)
        {
            this.ProductId = productId;
            this.productName = productName;
            this.Vat = VAT;
            this.ItemModelId = modelId;
            this.ModelName = modelName;
            this.ModelPrice = modPrice;
            this.InStock = modInStock;
        }
        public Model()
        {

        }

        public void AddModel(List<Model> list, int id, string Name)
        {
            int modelId, y;
            bool modInStock;
            double modPrice;


            while (true)
            {
                Console.WriteLine("Enter Item Model Id :");
                try
                {
                    int x = Convert.ToInt32(Console.ReadLine());
                    if (x > 0)
                    {
                        modelId = x;
                    }
                    else
                    {
                        throw new ModelIdException();
                    }
                    break;
                }
                catch (ModelIdException exp )
                {
                    Console.WriteLine("exception.message2");
                }
                catch (Exception)
                {
                    Console.WriteLine("Enter Valid Exception :");
                }
            }
            Console.WriteLine("Enter the Model Name :");

            string modName = Console.ReadLine();
            Console.WriteLine("Enter The Model Price :");
            while (true)
            {
                try
                {
                    modPrice = Convert.ToDouble(Console.ReadLine());
                    break;
                }
                catch (Exception)
                {
                    Console.WriteLine(" Enter the valid input :");
                }
            }
            Vat = CaluculateVat(modPrice);
            Console.WriteLine(" Instock ? Yes=1/No=0");
            y = Convert.ToInt16(Console.ReadLine());
            if (y == 1)
            {
                modInStock = true;
            }
            else
            {
                modInStock = false;
            }


            list.Add(new Model(id, productName, modelId, modName, modPrice, Vat, modInStock));

        }

        public void DeleteModel(List<Model> list)
        {
            try
            {
                if (list.Count == 0)
                {
                    throw (new NoModelsException());
                }
                int count = 0, flag = 0;
                Console.WriteLine("Enter model id:");
                int mId = Convert.ToInt32(Console.ReadLine());
                foreach (Model m in list)
                {
                    if (m.ItemModelId == mId)
                    {
                        list.RemoveAt(count);
                        Console.WriteLine("Model with model id {0} is successfully removed!", mId);
                        flag = 1;
                        break;
                    }
                    count++;
                }
                if (flag == 0)
                {
                    throw (new ModelIdException(mId));
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
            catch (ModelIdException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
        }

        public void DisplayAllModels(List<Model> list)
        {

            try
            {

                if (list.Count == 0)
                {
                    throw (new NoModelsException());
                }
                else
                {
                    foreach (Model m in list)
                    {
                        Console.WriteLine("\n---------------------------------\n");
                        Console.WriteLine(m);
                        Console.WriteLine("\n---------------------------------\n");

                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
        }

        public void ModifyPrice(List<Model> list)
        {
            try
            {
                if (list.Count == 0)
                {
                    throw (new NoModelsException());
                }
                int count = 0, flag = 0;
                Console.WriteLine("Enter model id:");
                int mId = Convert.ToInt32(Console.ReadLine());
                foreach (Model m in list)
                {
                    if (m.ItemModelId == mId)
                    {
                        Console.WriteLine("Enter new price:");
                        double p = Convert.ToDouble(Console.ReadLine());
                        m.ModelPrice = p;
                        Console.WriteLine("Price for model id {0} is successfully updated!", mId);
                        flag = 1;
                        break;
                    }
                    count++;
                }
                if (flag == 0)
                {
                    throw (new ModelIdException(mId));
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
            catch (ModelIdException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }
        }

        public void LowestPricedModel(List<Model> list)
        {
            try
            {
                if (list.Count == 0)
                {
                    throw (new NoModelsException());
                }
                double temp;


                temp = list.First().ModelPrice;
                for (int i = 1; i < list.Count(); i++)
                {
                    if (list.ElementAt(i).ModelPrice < temp)
                    {
                        temp = list.ElementAt(i).ModelPrice;
                    }
                }
                foreach (Model m in list)
                {
                    if (m.ModelPrice == temp)
                    {


                        Console.WriteLine("\n---------------------------------\n");
                        Console.WriteLine(m);
                        Console.WriteLine("\n---------------------------------\n");
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");
            }

        }

        public void ModelsInAPriceRange(List<Model> list)
        {
            try
            {
                if (list.Count == 0)
                {
                    throw (new NoModelsException());
                }

                Console.WriteLine("Enter Start Price:");
                double sp = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Enter End Price:");
                double ep = Convert.ToDouble(Console.ReadLine());

                foreach (Model m in list)
                {
                    if (m.ModelPrice >= sp && m.ModelPrice <= ep)
                    {
                        Console.WriteLine("\n---------------------------------\n");
                        Console.WriteLine("Model Name:\t{0} Price:\t{1}", m.ModelName, m.ModelPrice);
                        Console.WriteLine("\n---------------------------------\n");
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");

            }

        }

        public void DisplayOneModel(List<Model> list)
        {
            try
            {
                if (list.Count == 0)
                {
                    throw (new NoModelsException());
                }
                Console.WriteLine("Enter model id:");
                int id = Convert.ToInt32(Console.ReadLine());
                foreach (Model m in list)
                {
                    if (m.ItemModelId == id)
                    {
                        Console.WriteLine("\n---------------------------------\n");
                        Console.WriteLine(m);
                        Console.WriteLine("\n---------------------------------\n");
                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");

            }
        }

        public void CheckAvailable(List<Model> list)
        {
            try
            {
                if (list.Count == 0)
                {
                    throw (new NoModelsException());
                }
                Console.WriteLine("Enter model id:");
                int id = Convert.ToInt32(Console.ReadLine());
                foreach (Model m in list)
                {
                    if (m.ItemModelId == id)
                    {
                        if (m.InStock == true)
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine("\tAvailable!");
                            Console.WriteLine("\n---------------------------------\n");
                        }
                        else
                        {
                            Console.WriteLine("\n---------------------------------\n");
                            Console.WriteLine("\tNot Available!");
                            Console.WriteLine("\n---------------------------------\n");
                        }

                    }
                }
            }
            catch (NoModelsException exp)
            {
                Console.WriteLine("\n---------------------------------\n");
                Console.WriteLine(exp.Message1);
                Console.WriteLine("\n---------------------------------\n");

            }
        }

    }
    class ModelIdException : ApplicationException
    {
        string message1;
        public string Message1 { get { return message1; } set { message1 = value; } }

        string message2;
        public string Message2 { get { return message2; } set { message2 = value; } }

        public ModelIdException(int id)
            : base("Model Id Exception:")
        {
            Message1 = "Model with id " + id + " doesn't exist!";

        }

        public ModelIdException()
            : base("Model Id must be greater than zero.")
        {
            Message2 = "Model ID must be greater than zero.";
        }
    }
    class NoModelsException : ApplicationException
    {
        string msg0;
        public string Message1 { get { return msg0; } set { msg0 = value; } }
        public NoModelsException()
            : base("No Models Exception.")
        {
            Message1 = "There are no models added.";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Model m = new Model();
            List<Model> MobileList = new List<Model>();
            List<Model> IpodList = new List<Model>();
            List<Model> GameBoxList = new List<Model>();

            int endMainLoop = 0;

            Console.WriteLine("---Application to keep track of products sold by a company---");

            while (endMainLoop == 0)
            {
                int choice;
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.BackgroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("\n---------------------------------------------\n");
                Console.WriteLine("1.Mobile     2.i-pod     3.Game-Box      4.Exit");
                Console.WriteLine("\n---------------------------------------------\n");
                while (true)
                {
                    try
                    {
                        choice = Convert.ToInt32(Console.ReadLine());
                        break;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Enter valid choice.");
                    }
                }

                switch (choice)
                {
                    case 1:
                        int x = 0;
                        while (x == 0)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.BackgroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("\n------------------------------------------------------------------------\n");
                            Console.WriteLine("\n1. Add Model         2.Delete Model                3.Display All Models" +
                                "\n4.Modify Price       5.Lowest Priced Model         6.Models In A Price Range" +
                                "\n7.Display 1 Model    8.Check Availability Of Model 9.Exit");
                            Console.WriteLine("Selected Choice:");
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.BackgroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            int ch;
                            while (true)
                            {
                                try
                                {
                                    ch = Convert.ToInt32(Console.ReadLine());
                                    break;
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine("Enter valid choice.");
                                }
                            }
                            switch (ch)
                            {
                                case 1:
                                    m.AddModel(MobileList, 101, "Mobile");
                                    break;
                                case 2:
                                    m.DeleteModel(MobileList);
                                    break;
                                case 3:
                                    m.DisplayAllModels(MobileList);
                                    break;
                                case 4:
                                    m.ModifyPrice(MobileList);
                                    break;
                                case 5:
                                    m.LowestPricedModel(MobileList);
                                    break;
                                case 6:
                                    m.ModelsInAPriceRange(MobileList);
                                    break;
                                case 7:
                                    m.DisplayOneModel(MobileList);
                                    break;
                                case 8:
                                    m.CheckAvailable(MobileList);
                                    break;
                                case 9:
                                    x = -1;
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid Choice.");
                                    break;
                            }
                        }
                        break;
                    case 2:
                        int x1 = 1;
                        while (x1 == 1)
                        {
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.BackgroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("\n1. Add Model         2.Delete Model                3.Display All Models" +
                                    "\n4.Modify Price       5.Lowest Priced Model         6.Models In A Price Range" +
                                    "\n7.Display 1 Model    8.Check Availability Of Model 9.Exit");
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.BackgroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("Selected Choice:");

                            int ch;

                            while (true)
                            {
                                try
                                {
                                    ch = Convert.ToInt32(Console.ReadLine());
                                    break;
                                }
                                catch (Exception)
                                {
                                    Console.WriteLine("Enter valid choice.");
                                }
                            }
                            switch (ch)
                            {
                                case 1:
                                    m.AddModel(IpodList, 101, "Ipod");
                                    break;
                                case 2:
                                    m.DeleteModel(IpodList);
                                    break;
                                case 3:
                                    m.DisplayAllModels(IpodList);
                                    break;
                                case 4:
                                    m.ModifyPrice(IpodList);
                                    break;
                                case 5:
                                    m.LowestPricedModel(IpodList);
                                    break;
                                case 6:
                                    m.ModelsInAPriceRange(IpodList);
                                    break;
                                case 7:
                                    m.DisplayOneModel(IpodList);
                                    break;
                                case 8:
                                    m.CheckAvailable(IpodList);
                                    break;
                                case 9:
                                    x1 = -1;
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid Choice.");
                                    break;
                            }
                        }
                        break;
                    case 3:
                        int x2 = 0;
                        while (x2 == 0)
                        {

                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("\n1. Add Model         2.Delete Model                3.Display All Models" +
                                    "\n4.Modify Price       5.Lowest Priced Model         6.Models In A Price Range" +
                                    "\n7.Display 1 Model    8.Check Availability Of Model 9.Exit");
                            Console.WriteLine("\n------------------------------------------------------------------------\n");

                            Console.WriteLine("Selected Choice:");
                            int ch = Convert.ToInt32(Console.ReadLine());
                            switch (ch)
                            {
                                case 1:
                                    m.AddModel(GameBoxList, 103, "Game Box");
                                    break;
                                case 2:
                                    m.DeleteModel(GameBoxList);
                                    break;
                                case 3:
                                    m.DisplayAllModels(GameBoxList);
                                    break;
                                case 4:
                                    m.ModifyPrice(GameBoxList);
                                    break;
                                case 5:
                                    m.LowestPricedModel(GameBoxList);
                                    break;
                                case 6:
                                    m.ModelsInAPriceRange(GameBoxList);
                                    break;
                                case 7:
                                    m.DisplayOneModel(GameBoxList);
                                    break;
                                case 8:
                                    m.CheckAvailable(GameBoxList);
                                    break;
                                case 9:
                                    x2 = -1;
                                    break;
                                default:
                                    Console.WriteLine("Enter Valid Choice.");
                                    break;
                            }
                        }
                        break;
                    case 4:
                        endMainLoop = 1;
                        break;
                    default:
                        Console.WriteLine("Enter Valid Choice.");
                        break;
                }
            }


        }
    }
}
