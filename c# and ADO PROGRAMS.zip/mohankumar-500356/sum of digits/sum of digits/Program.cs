﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum_of_digits
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            int rev = 0;
            Console.WriteLine("enter num");
            int.TryParse(Console.ReadLine(), out num);
            while(num!=0)
            {
                int r = num % 10;
                rev = rev + r;
                num = num / 10;
            }
            Console.WriteLine("sum of digits" +rev);
        }
    }
}
