﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] matrix = new int[10][];


            for (int i = 0; i < matrix.Length; i++)
            {
                matrix[i] = new int[3]; // Create inner array
                Console.WriteLine("i--------------------------------"+i);
                for (int j = 0; j < 2; j++)
                {

                    matrix[i][j] = i * 3;
                    Console.WriteLine(matrix[i][j]);
                }
            }
        }
    }
}
