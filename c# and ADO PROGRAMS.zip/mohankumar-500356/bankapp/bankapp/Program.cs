﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationForBankAccount

{


    class Program
    {
        public static List<SavingAccount> S = new List<SavingAccount>();
        public static List<CurrentAccount> C = new List<CurrentAccount>();

        static void Main(string[] args)
        {

            string confirm = "";
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.WriteLine("******WELCOME TO ONLINE BANK SERVICES******\n");
            do
            {

                DisplayMenu1();

                Console.BackgroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.Black;
                int Choice_A = GetInt("Enter the choice");

                switch (Choice_A)
                {
                    case 1:
                        {
                            SavingAccount SA1 = new SavingAccount();

                            DisplayMenu2();
                            int Choice_B = GetInt("Enter the choice");

                            switch (Choice_B)
                            {
                                case 1:

                                    SA1.OpenAccount();
                                    S.Add(SA1);
                                    break;
                                case 2:

                                    SA1.CloseAccount();
                                    break;
                                case 3:

                                    SA1.EditAccount();
                                    break;
                                case 4:

                                    SA1.Deposit();
                                    break;
                                case 5:

                                    SA1.Withdrawal();
                                    break;
                                case 6:

                                    SA1.Check_Balance();
                                    break;
                                case 7:

                                    SA1.GetAccountDetails();
                                    break;

                                case 8:

                                    SA1.TransferAmount();
                                    break;
                                case 9:

                                    SA1.GetRateOfInterest();
                                    break;
                            }
                            break;
                        }
                    case 2:
                        {
                            DisplayMenu2();
                            int Choice_C = GetInt("Enter the choice");
                            CurrentAccount CA1 = new CurrentAccount();
                            switch (Choice_C)
                            {
                                case 1:

                                    CA1.OpenAccount(CA1);
                                    C.Add(CA1);
                                    break;
                                case 2:

                                    CA1.CloseAccount();
                                    break;
                                case 3:

                                    CA1.EditAccount();
                                    break;
                                case 4:

                                    CA1.Deposit();
                                    break;
                                case 5:

                                    CA1.Withdrawal();
                                    break;
                                case 6:

                                    CA1.Check_Balance();
                                    break;
                                case 7:

                                    CA1.GetAccountDetails();
                                    break;
                                case 8:
                                    CA1.TransferAmount();
                                    break;
                                case 9:
                                    CA1.GetRateOfInterest();
                                    break;
                            }
                            break;
                        }
                }

                // default:
                Console.WriteLine("Enter 'y' to continue");
                confirm = Console.ReadLine().ToUpper();
                //break;

            }
            while (confirm == "Y");
        }

        private static int GetInt(string message)
        {
            int val = 0;
            while (true)
            {
                Console.WriteLine(message);
                if (int.TryParse(Console.ReadLine(), out val))
                    // if(val==1||val==2)
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The entered number is not in correct format. Please try again!");
                Console.ResetColor();
            }
            return val;
        }



        public static void DisplayMenu1()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("***Choose one***\n");
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1.Saving Account");
            Console.WriteLine("2.Current Account");
        }
        private static void DisplayMenu2()
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1.Open an Account:");
            Console.WriteLine("2.Close an Account");
            Console.WriteLine("3.Edit your Account");
            Console.WriteLine("4.Deposit");
            Console.WriteLine("5.Withdrawal");
            Console.WriteLine("6.Check your Account balance");
            Console.WriteLine("7.Get acount details");
            Console.WriteLine("8.Transfer amount");
            Console.WriteLine("9.Get interest");

        }
    }
    public abstract class Account
    {

        public string name;

        public Account()
        {
            this.an = AccountNumber();
        }
        long AccountNumber()
        {
            long acc_num = 0;
            Random r = new Random();
            string w = " ";
            int i;
            for (i = 1; i < 13; i++)
            {
                w += r.Next(0, 9).ToString();
            }
            if (w.Length == 12)
            {
                acc_num = Convert.ToInt64(w);

            }

            return acc_num;

        }
        public readonly long an;
        // string UserName = Console.ReadLine();
        public long Balance = 0;
        public void OpenAccount() { }
        public abstract void CloseAccount();

        public abstract void EditAccount();
        public abstract void Deposit();
        public abstract void Withdrawal();
        public abstract void Check_Balance();

    }
    public class SavingAccount : Account
    {
        int MaxAmountPerDayS = 10000;
        int minbal = 1000;




        public override void Check_Balance()
        {
            Console.WriteLine("Enter your account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.S)
            {
                count++;
                if (an == numcheck)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"Your available balance is {Balance}");
                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }

        }
        public override void Deposit()
        {
            Console.WriteLine("Enter the amount number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.S)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine($"Account name: {item.name}");
                    Console.WriteLine("Enter the amount to be deposited");
                    long deposit = Convert.ToInt64(Console.ReadLine());
                    try
                    {
                        if (deposit < MaxAmountPerDayS)
                        {
                            item.Balance += deposit;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Amount is deposited succesfully");
                            Console.ResetColor();
                        }
                        else
                        {
                            throw new MaximumDepositAmtException("You can not deposit amount greater than 10000");

                        }

                    }
                    catch (MaximumDepositAmtException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                }
                else if (count == Program.S.Count)
                {
                    Console.WriteLine("Please enter the valid account number");
                }
            }
        }
        public override void EditAccount()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.S)
            {
                count++;

                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the username to be modified");
                    item.name = Console.ReadLine();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Your username is modified successfully");
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.ResetColor();
                    break;
                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }

            }
        }



        public new void OpenAccount()
        {


            Console.WriteLine("Enter your name:");
            name = Console.ReadLine();
            Console.WriteLine("Enter the amount to be deposited");
            Balance = Convert.ToInt64(Console.ReadLine());

            if (Balance >= 1000)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Savings account is created successfully");
                Console.ReadLine();
                Console.ResetColor();
                Console.WriteLine($"Account number : {an}");
                Console.WriteLine($"Account name : {name}");
                Console.WriteLine($"Account Balance : {Balance}");
                Console.ReadLine();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Amount should be more than 1000 to create an account");
                Console.ResetColor();
            }
        }


        public override void Withdrawal()
        {

            Console.WriteLine("Enter the amount to be withdrawn:");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.S)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the amount to be Withdrawn");
                    int withdraw = Convert.ToInt32(Console.ReadLine());

                    try
                    {

                        if (withdraw < MaxAmountPerDayS)
                        {

                            if ((item.Balance - withdraw) > minbal)
                            {
                                item.Balance -= withdraw;
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Amount is withdrawn successfully");
                                Console.ResetColor();
                            }

                            else
                            {
                                throw new minBalException("Withdrawal Error!-minBalance after withdrawal should be greater than 1000");
                            }

                        }

                        else
                        {
                            throw new MaxwithdrawalAmount("You can not withdraw ammount greater than 10000");
                        }
                    }
                    catch (minBalException e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.Message);
                        Console.ResetColor();

                    }

                    catch (MaxwithdrawalAmount e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.Message);
                        Console.ResetColor();


                    }
                    break;

                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please enter the valid account number");
                    Console.ResetColor();
                }

            }


        }
        public void GetAccountDetails()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.S)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountNumber:{0}", item.an);
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("AccountBalance:{0}", item.Balance);
                    break;
                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }

        public override void CloseAccount()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.S)
            {
                count++;
                try
                {
                    if (item.an == numcheck)
                    {
                        if (item.Balance == 0)
                        {
                            Program.S.Remove(item);
                        }
                        else
                        {
                            throw new AccountCloseException((" To close the Account the balance should be zero"));
                        }
                    }
                    else if (count == Program.S.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Enter the valid account number");
                        Console.ResetColor();
                    }
                }
                catch (AccountCloseException e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();
                }
            }
        }
        public void TransferAmount()
        {
            long fromaccount;
            long toaccount;
            Console.WriteLine("Enter the From account number");
            fromaccount = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.S)
            {
                count++;
                if (item.an == fromaccount)
                {
                    Console.WriteLine("Enter To account number");
                    toaccount = Convert.ToInt64(Console.ReadLine());
                    for (int i = 0; i < Program.S.Count; i++)
                    {

                        if (Program.S[i].an == toaccount)
                        {

                            Console.WriteLine("Enter the ammount to be transfered");
                            int amount = Convert.ToInt32(Console.ReadLine());
                            if (fromaccount != toaccount)
                            {
                                if (Balance > amount + minbal)
                                {
                                    item.Balance = Balance - amount;
                                    Program.S[i].Balance = Program.S[i].Balance + item.Balance;

                                }
                            }

                        }

                    }
                }
            }
        }
        public void GetRateOfInterest()
        {

            float principle = 0;
            float timeinyears;
            float rateofinterest = 4;
            Console.WriteLine("Enter Principle ammount");
            principle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the time in years");
            timeinyears = Convert.ToInt32(Console.ReadLine());
            float simpleinterst = (principle * timeinyears * rateofinterest) / 100;
            Console.WriteLine("simple interest is ", simpleinterst);

        }
    }
    public class CurrentAccount : Account
    {

        int MaxAmountPerDayC = 10000;
        int minbal = 1000;
        public override void Check_Balance()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.C)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountBalance:{0}", item.Balance);
                    break;
                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }



        public override void Deposit()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.C)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the amount to be deposited");
                    int deposit = Convert.ToInt32(Console.ReadLine());
                    // To check the amount is in valid range
                    // int amnt = 0;
                    //amnt = amnt + deposit;

                    try
                    {
                        if (deposit < MaxAmountPerDayC)
                        {
                            item.Balance += deposit;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Amount is deposited successfully");
                            Console.ResetColor();
                        }

                        else
                        {
                            throw new MaxDepositAmtException("You can not deposit ammount greater than 1000000 ");
                        }
                    }
                    catch (MaxDepositAmtException e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.Message);
                        Console.ResetColor();

                    }
                    break;

                }
                else if (count == Program.S.Count)
                {
                    Console.WriteLine("Please enter the valid account number");
                }

            }
        }
        public override void EditAccount()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.C)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the  new username ");
                    item.name = Console.ReadLine();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Your username is modified successfully");
                    Console.ResetColor();
                    Console.WriteLine("AccountName:{0}", item.name);
                    break;
                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please enter the valid Account number");
                    Console.ResetColor();
                }
            }

        }
        public void OpenAccount(CurrentAccount obj)
        {
            Console.WriteLine("Enter the username");
            obj.name = Console.ReadLine();
            Console.WriteLine("Enter the amount to be deposited");
            obj.Balance = Convert.ToInt32(Console.ReadLine());
            if (obj.Balance >= minbal)
            {
                Program.C.Add(obj);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Savings Account is created successfully ");
                Console.ResetColor();
                Console.WriteLine("AccountNumber:{0}", obj.an);
                Console.WriteLine("AccountName:{0}", obj.name);
                Console.WriteLine("AccountBalance:{0}", obj.Balance);
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Amount should be morethan 10000 to create an account");
                Console.ResetColor();
            }
        }
        public override void Withdrawal()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.C)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("Enter the amount to be Withdrawn");
                    int withdraw = Convert.ToInt32(Console.ReadLine());


                    try
                    {

                        if (withdraw < MaxAmountPerDayC)
                        {

                            if ((item.Balance - withdraw) > minbal)
                            {
                                item.Balance -= withdraw;
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Amount is withdrawn successfully");
                                Console.ResetColor();
                            }

                            else
                            {
                                throw new minBalException("Withdrawal Error!-minBalance after withdrawal should be greater than 1000");
                            }

                        }

                        else
                        {
                            throw new MaxwithdrawalAmount("You can not withdraw ammount greater than 50000");
                        }
                    }
                    catch (minBalException e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.Message);
                        Console.ResetColor();


                    }

                    catch (MaxwithdrawalAmount e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.Message);
                        Console.ResetColor();


                    }
                    break;

                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Please entere the valid account number");
                    Console.ResetColor();
                }

            }
        }
        public void GetAccountDetails()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.C)
            {
                count++;
                if (item.an == numcheck)
                {
                    Console.WriteLine("AccountNumber:{0}", item.an);
                    Console.WriteLine("AccountName:{0}", item.name);
                    Console.WriteLine("AccountBalance:{0}", item.Balance);
                    break;
                }
                else if (count == Program.S.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Enter the valid account number");
                    Console.ResetColor();
                }
            }
        }



        public override void CloseAccount()
        {
            Console.WriteLine("Enter the account number");
            long numcheck = Convert.ToInt64(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.C)
            {
                count++;
                try
                {
                    if (item.an == numcheck)
                    {

                        if (item.Balance == 0)
                        {
                            Program.C.Remove(item);
                        }
                        else
                        {
                            throw new AccountCloseException((" To close the Account the balance should be zero"));
                        }
                        break;
                    }
                    else if (count == Program.S.Count)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Enter the valid account number");
                        Console.ResetColor();
                    }
                }
                catch (AccountCloseException e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ResetColor();
                }
            }
        }
        public void TransferAmount()
        {
            long fromaccount;
            long toaccount;
            Console.WriteLine("Enter the From account number");
            fromaccount = Convert.ToInt32(Console.ReadLine());
            int count = 0;
            foreach (var item in Program.C)
            {
                count++;
                if (item.an == fromaccount)
                {
                    Console.WriteLine("Enter To account number");
                    toaccount = Convert.ToInt32(Console.ReadLine());
                    for (int i = 0; i < Program.C.Count; i++)
                    {

                        if (Program.C[i].an == toaccount)
                        {

                            Console.WriteLine("Enter the ammount to be transfered");
                            int amount = Convert.ToInt32(Console.ReadLine());
                            if (fromaccount != toaccount)
                            {
                                if (Balance > amount + minbal)
                                {
                                    item.Balance = Balance - amount;
                                    Program.C[i].Balance = Program.C[i].Balance + item.Balance;

                                }
                            }

                        }

                    }
                }
            }
        }
        public void GetRateOfInterest()
        {

            float principle = 0;
            float timeinyears;
            float rateofinterest = 4;
            Console.WriteLine("Enter Principle ammount");
            principle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the time in years");
            timeinyears = Convert.ToInt32(Console.ReadLine());
            float simpleinterst = (principle * timeinyears * rateofinterest) / 100;
            Console.WriteLine("simple interest is ", simpleinterst);

        }
    }

    interface IROI
    {

        void GetRateOfInterest();
    }
    interface ITransaction
    {
        int FromAccount { get; set; }
        int ToAccount { get; set; }
        void TransferAmount();

    }

    class minBalException : Exception
    {
        public minBalException(string message) : base(message) { }
    }

    class MaxwithdrawalAmount : Exception
    {
        public MaxwithdrawalAmount(string message) : base(message) { }
    }

    class MaxDepositAmtException : Exception
    {
        public MaxDepositAmtException(string message) : base(message) { }
    }
    class AccountCloseException : Exception
    {
        public AccountCloseException(string message) : base(message) { }
    }
    class MaximumDepositAmtException : Exception
    {
        public MaximumDepositAmtException(string message) : base(message) { }
    }
}
