﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arry
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] matrix = new int[3][];
           

            for (int i = 0; i < matrix.Length; i++)
            {
                matrix[i] = new int[3]; // Create inner array
                Console.WriteLine(i);
                for (int j = 0; j < matrix[i].Length; j++)
                    matrix[i][j] = i * 3 ;
                Console.WriteLine(matrix[i][j]);
            }

        }
    }
}
     