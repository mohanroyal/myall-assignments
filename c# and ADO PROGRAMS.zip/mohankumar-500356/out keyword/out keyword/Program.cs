﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace out_keyword
{
    class Program
    {
        private static bool ans;
        private static int d;

        public static void add(out int c, int b, int a,out int d,out int ans)
        {
            c = a + b;
            d = a - b;
            ans = a * b;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("adding two numbers");
            int c;
            int d;
            int ans;
            add(out c, 5, 5,out d,out ans);
            Console.WriteLine(c);
            Console.WriteLine(d);
            Console.WriteLine(ans);
        }
    }
}
