﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prime
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number");
            int num = int.Parse(Console.ReadLine());
            test(num);
        }
        static void test(int num)
        {
            int count = isprime(num);
            if (count == 0)
            {
                Console.WriteLine("true");
            }
            else
            {
                Console.WriteLine("false");
            }
        }
           static int isprime(int num)
        {
            int count = 0;
           int n = num / 2;
            for (int i = 2; i <= n ; i++)
            {
                if (n % i == 0)
                {
                    count = 1;
                    break;
                }

            }
            return count;
            }
        }
        }
              
    
