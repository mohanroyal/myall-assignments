﻿using System.Linq;
using System.Text;
using System;

namespace CustomExtensions
{
    
    public static class StringExtension
    {
        
        public static int WordCount(this String str)
        {
            return str.Split(new char[] { ' ', '.', '?',':' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }
    }
}
namespace Extension_Methods_Simple
{
    
    using CustomExtensions;
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the string");
            string s = Console.ReadLine();
            int i = s.WordCount();
            System.Console.WriteLine("Word count of s is {0}", i);
        }
    }
}