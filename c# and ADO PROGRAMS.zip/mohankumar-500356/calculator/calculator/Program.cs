﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    //delegate int MyDelegate(int i, int j);
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter frst number");
            int i = int.Parse(Console.ReadLine());
            Console.WriteLine( "enter second number");
            int j = int.Parse(Console.ReadLine());
            Console.WriteLine("1. add 2. sub 3. mul 4. div");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    sum(i, j);
                    //MyDelegate del = sum ;
                    //del(i, j);
                    break;
                case 2:
                    sub(i,j);
                    //MyDelegate del1 = sub;
                   //del1(i, j);
                    break;
                case 3:
                    mul(i,j);
                    //MyDelegate del2 = mul;
                    //del2(i, j);
                    break;
                case 4:
                    div(i, j);
                    //MyDelegate del3 = div;
                    //del3(i, j);
                    break;

            }

        }
        public static void sum(int i, int j)
        {

            Console.WriteLine("the sum is " + (i+j));
        }

        public static void sub(int i, int j)
        {
      
            Console.WriteLine("the sub is"+(i-j));
        }

        public static void mul(int i, int j)
        {
            int mul = i * j;
            Console.WriteLine("the mul is "+mul);
        }
        private static void div(int i, int j)
        {
            
            Console.WriteLine("the dev is " +(i / j));
        }

    }
}
