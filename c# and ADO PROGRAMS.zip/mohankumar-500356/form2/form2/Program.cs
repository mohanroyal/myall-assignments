﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace form2
{
   
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Window windo= new Window();
            windo.Height = 400;
            windo.Width = 300;
            windo.Title = "my frst form";
            Button bt = new Button();
            bt.Height = 20;
            bt.Width = 10;
            windo.Content = bt;
            bt.Click += (s, e) => { MessageBox.Show("hello");};
            Application app = new Application();
            app.Run(windo);
        }
    }
}
