﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace join
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Console.WriteLine("main method started");
            Thread th = new Thread(new ThreadStart(test));
            Thread th1 = new Thread(new ThreadStart(mohan));
            th.Start();
            th1.Start();

        }
        static void test()
        {
            for (int i = 0; i < 10; i++)
                Console.WriteLine("starting of thread {0}", i);
            Console.WriteLine("main method ended");
        }
        static void mohan()
        {
            for (int j = 0; j < 50; j++)
            {
                if (j % 2 == 0)
                {
                   
                        
                    Console.WriteLine("enven number is " + j);
                    }
                else
                {

                    Console.WriteLine("odd number is " + j);
                }
            }
        }
    }
}