﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO3
{
    class Program
    {
        static string Constring = Properties.Settings.Default.Constring;
        static void Main(string[] args)
        {
            using (SqlConnection con = new SqlConnection(Constring))
            {
                string cmdstring = @"select * from Employees";
                con.Open();
                using (SqlCommand cmd = new SqlCommand(cmdstring, con))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    DataRow dr = ds.Tables[0].NewRow();
                    dr["Firstname"] = "Donald";
                    dr["Lirstname"] = "Trump";
                    DataTable dt = ds.Tables[0];
                    dt.Rows.Add(dr);
                    {
                        da.Update(ds);
                    }
                }
            }
        }
    }
}