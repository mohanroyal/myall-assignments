﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace interest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter principal amount");
            double p = double.Parse(Console.ReadLine());
            Console.WriteLine("emnter period of years");
            double t = double.Parse(Console.ReadLine());
            Console.WriteLine("enter the rate of interest");
            double r = double.Parse(Console.ReadLine());
            Console.WriteLine("the principle amnt is:"+p+"\t time period is :"+t+"\t rate of interest is:"+r+" \t simple interest is :"+interest(p,t,r));
        }
        static double interest(double p,double t,double r)
        {
            return (p * t * r) / 100;
        }
    }
}
