﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ref2
{
    class Program
    {
        static void Main(string[] args)
        {
            test a = new ref2.Program.test();
            int b = 20;
            Console.WriteLine(b);
            a.sqr(ref b);
            Console.WriteLine(b);
        }
        class test
        {
            public void sqr(ref int a)
            {
                a = a * a;
            }
        }
    }
}
