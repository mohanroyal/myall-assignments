﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace median_mode
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the size");
            int size = int.Parse(Console.ReadLine());
            int[] arr = new int[size];
            for (int i = 0; i < size; i++)
            {
                int.TryParse( Console.ReadLine(),out arr[i]);
            }
            Console.WriteLine("elements in the array are:");
            for(int i=0;i<size;i++)
            {
                Console.WriteLine(arr[i]);
            }
            int[] a = sort(arr);
            Console.WriteLine("Mean is "+mean(a));
            Console.WriteLine("Median is "+median(a));
            Console.WriteLine("Mode is "+mode(a));
        }
        static int[] sort(int[] arr)
        {
            for(int i=0;i<arr.Length;i++)
            {
                for(int j=i+1;j<arr.Length-1;j++)
                {
                   if(arr[i]>arr[j])
                    {
                        int temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            return arr;      
        }
        static double mean(int[] a)
        {
            int sum = 0;
            for (int i = 0; i < a.Length; i++)
            {
                sum = sum + a[i];
            }
            return sum / a.Length;
        }
        static double median(int[] a)
        {
            if(a.Length%2==0)
            {
                return a[((a.Length / 2) + ((a.Length / 2) + 1)) / 2];
            }
            return a[(a.Length + 1) / a.Length];
        }
        static int mode(int[] a)
        {
            int[] count = new int[a.Length];
            int k=0,max1=0,max=0;
            for(int i=0;i<a.Length;i++)
            {
                for(int j=i+1;j<a.Length;j++)
                {
                     max = 0;
                    
                    
                        if ( a[i] == a[j])
                        {

                        max++;
                       
                    }
                    
                   

                }
                if(max>max1)
                {
                    k = i;
                    max1 = max;
                }
               
            }
           
            return a[k];
        }
        }
    }