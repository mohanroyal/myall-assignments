﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            Func<int, bool> isOddDelegate = i => (i&1) == 1;
            for (int i = 0; i < 10; i++)
            {
                if (isOddDelegate(i))
                    Console.WriteLine(i + " is odd");
                else
                    Console.WriteLine(i + " is even");
            }
        }

    }
}
